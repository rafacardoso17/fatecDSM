const fs = require('fs');

const dadosPratos = fs.readFileSync('json/pratos.json');

const jsonPratos = JSON.parse(dadosPratos);

use('FoodClub')
db.pratos.insertMany(jsonPratos);
db.pratos.find();

//Listar o nome de todos os pratos
use('FoodClub')
db.pratos.find({}, {nome: 1, _id:0})

// Maior que 15 menos que 20
use('FoodClub')
db.pratos.find({ preco: { $gt: 15, $lt: 20 } })

// Nome que contém Frango ou Carne
use('FoodClub')
db.pratos.find({ nome: { $regex: /frango|carne/i } })

//Listar pratos e associar a localização do restaurante
use('FoodClub')
db.pratos.aggregate([
  {
    $lookup: {
      from: "restaurantes",
      localField: "id_restaurante",
      foreignField: "_id",
      as: "local_restaurante"
    }
  },
  {
    $project: {
      nome: 1,
      preco: 1,
      "local_restaurante.local.coordinates": 1
    }
  }
])