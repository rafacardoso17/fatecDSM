"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var PromptSync = require("prompt-sync");
var prompt = PromptSync();
var numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
var numero = prompt("Digite um número maior que 10: ");
numeros.push(Number(numero));
console.log(numeros);
