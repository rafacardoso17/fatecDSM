const mensagem : string = 'Hello world';
console.log(mensagem);
