//sintaxe
//nomedavariavel : tipo
//string, boolean, number
//string = caracters alfanúmericos entre "", ou ''
const nome : string = 'Janaina';
const sobrenome : string = "Ferreira";

//concatenar strings
const nomeCompleto : string = nome + " " + sobrenome;
const nomeCompleto2 : string = `nome: ${nome} sobrenome: ${sobrenome}`;

//testando o tipo string
const numero1 : string = "10";

const isLoading : boolean = true; //true ou false 

const numeros : number = 10 //inteiros, floats, doubles, hexadecimal, octal

