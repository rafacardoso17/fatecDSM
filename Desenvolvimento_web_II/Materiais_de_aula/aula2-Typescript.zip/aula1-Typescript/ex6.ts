import PromptSync = require('prompt-sync')
const prompt = PromptSync()

const x: number = Number(prompt("Digite um numero:"))

if( x % 2 === 0){
    console.log("É par")
}else{
    console.log("É impar")
}