var carros = ["Celta", "Classic", "Uno"];
carros.push("Land Rover");
console.log(carros);
