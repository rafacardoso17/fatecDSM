"use strict";
const mensagem = 'Hello world';
console.log(mensagem);
