//funcão sem parâmetro e sem retorno
function imprime(){
    console.log("sem parâmetro e sem retorno")
}

//chamada da funcao
imprime()

//funcao com parâmetro e sem retorno
function soma (num1:number, num2:number){
    console.log(`Soma: ${num1 + num2}`)
}
//chamada da funcao
soma(1,2)

//funcao com parâmetro e com retorno
function subtrai (num1:number, num2:number) : number{
    return num1 - num2
}
//chamada da funcao
const resultado = subtrai(10,9)
console.log(resultado)