import PromptSync = require('prompt-sync')
const prompt = PromptSync()

const x: number = Number(prompt("Digite o 1o numero:"))
const y: number = Number(prompt("Digite o 2o numero: "))
const confere: number = Number(prompt("Digite o numero a ser pesquisado: "))

if (confere > x && confere < y) {
    console.log("Esta no intervalo")
} else {
    console.log("Não esta no intervalo")
}
