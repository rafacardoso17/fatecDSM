//funcão sem parâmetro e sem retorno
function imprime() {
    console.log("sem parâmetro e sem retorno");
}
