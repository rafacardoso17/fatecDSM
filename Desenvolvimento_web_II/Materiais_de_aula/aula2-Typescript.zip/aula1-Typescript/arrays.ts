const carros : Array<string> =["Celta", "Classic", "Uno"]
carros.push("Land Rover")
console.log(carros)

let diasDaSemana : ReadonlyArray<string> = ["segunda-feira", "terça-feira"]
//diasDaSemana.push() erro!!!!
console.log(diasDaSemana)