"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const promptSync = require("prompt-sync");
//import PromptSync from 'prompt-sync';
var prompt = promptSync();
//entrada de dados
const b = prompt("insira o valor para b: ");
//saida de dados
console.log(b);
const c = "segunda linha";
const d = "terceira linha";
