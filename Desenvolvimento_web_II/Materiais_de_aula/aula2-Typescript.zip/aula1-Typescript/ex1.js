"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//Exercício
// Crie um programa que receba um número do usuário
// e exiba seus 2 sucessores e seus 2 antecessores.
const promptSync = require("prompt-sync");
var prompt = promptSync();
var numero = Number(prompt("Digite um número: "));
const ant1 = numero - 1;
const ant2 = numero - 2;
console.log(`Sucessores = ${numero + 1},${numero + 2} 
    \nAntecessores = ${ant1},${ant2} `);
