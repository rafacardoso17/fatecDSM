"use strict";
//sintaxe
//nomedavariavel : tipo
//string, boolean, number
//string = caracters alfanúmericos entre "", ou ''
const nome = 'Janaina';
const sobrenome = "Ferreira";
//concatenar strings
const nomeCompleto = nome + " " + sobrenome;
const nomeCompleto2 = `nome: ${nome} sobrenome: ${sobrenome}`;
//testando o tipo string
const numero1 = "10";
const isLoading = true; //true ou false 
const numeros = 10; //inteiros, floats, doubles, hexadecimal, octal
