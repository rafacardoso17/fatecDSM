import promptSync = require('prompt-sync');

//import PromptSync from 'prompt-sync';

var prompt = promptSync();

//entrada de dados
const b: string = prompt("insira o valor para b: ")
//saida de dados
console.log(b)
const c: string = "segunda linha"
const d: string = "terceira linha"


